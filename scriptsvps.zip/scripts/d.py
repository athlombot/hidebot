# Librerías
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from random import randrange
import time

options = webdriver.ChromeOptions() 

driver = webdriver.Chrome('./webdriver/chromedriver')

print ("Iniciando Bot")

with open('./Credenciales/hideout.txt', 'r') as f:
    for line in f:
        line_words = line.split()

#Abrimos las Paginas

driver.execute_script('window.open("https://petclips.tv/login.php", "_blank", "resizable=yes, scrollbars=yes, titlebar=yes, width=500, height=500, top=1000, left=500");')

driver.switch_to.window(driver.window_handles[0])

driver.execute_script('window.open("http://mealninja.me/login.php", "_blank", "resizable=yes, scrollbars=yes, titlebar=yes, width=500, height=500, top=1000, left=1000");')

driver.switch_to.window(driver.window_handles[1])

driver.execute_script('window.open("http://tryathome.me/login.php", "_blank", "resizable=yes, scrollbars=yes, titlebar=yes, width=500, height=500, top=1000, left=1500");')

driver.switch_to.window(driver.window_handles[2])

#Eliminamos Pagina Extra

driver.switch_to.window(driver.window_handles[0])
time.sleep(2)
driver.close()

#Inicio de Sesion

driver.switch_to.window(driver.window_handles[0])

inputElement = driver.find_element_by_id("username")
inputElement.send_keys( line_words[0] )

time.sleep(1)

inputElement = driver.find_element_by_id("password")
inputElement.send_keys( line_words[1] )

element = WebDriverWait(driver, 10).until(
EC.element_to_be_clickable((By.XPATH, '//*[@id="login"]/div[4]/button')))
element.click();

driver.switch_to.window(driver.window_handles[1])
inputElement = driver.find_element_by_id("username")
inputElement.send_keys( line_words[0] )

time.sleep(1)

inputElement = driver.find_element_by_id("password")
inputElement.send_keys( line_words[1] )

element = WebDriverWait(driver, 10).until(
EC.element_to_be_clickable((By.XPATH, '//*[@id="login"]/div[4]/button')))
element.click();

time.sleep(1)

driver.switch_to.window(driver.window_handles[2])
inputElement = driver.find_element_by_id("username")
inputElement.send_keys( line_words[0] )

time.sleep(1)

inputElement = driver.find_element_by_id("password")
inputElement.send_keys( line_words[1] )

element = WebDriverWait(driver, 10).until(
EC.element_to_be_clickable((By.XPATH, '//*[@id="login"]/div[4]/button')))
element.click();

time.sleep(1)

#Iniciar Video en cada Ventana

driver.switch_to.window(driver.window_handles[0])

element = WebDriverWait(driver, 10).until(
EC.element_to_be_clickable((By.XPATH, '//*[@id="fragment-pane"]/div/div/div[1]/div[1]/a/div')))
element.click();

driver.switch_to.window(driver.window_handles[1])

element = WebDriverWait(driver, 10).until(
EC.element_to_be_clickable((By.XPATH, '//*[@id="fragment-pane"]/div/div/div[1]/div[1]/a/div')))
element.click();

driver.switch_to.window(driver.window_handles[2])

element = WebDriverWait(driver, 10).until(
EC.element_to_be_clickable((By.XPATH, '//*[@id="fragment-pane"]/div/div/div[1]/div[1]/a/div')))
element.click();

#Bajar Scroll

driver.switch_to.window(driver.window_handles[0])
driver.execute_script("window.scrollTo(50,document.body.scrollHeight)")

driver.switch_to.window(driver.window_handles[1])
driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")

driver.switch_to.window(driver.window_handles[2])
driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")

#Monitorear Cartel del Close

for cartel in range(0,10000):

    xpath = 'gotIt_rewards_inactive'
    count = len(driver.window_handles)

    for i in range(count):
        driver.switch_to.window(driver.window_handles[i])
        try:
            element = WebDriverWait(driver,10).until(EC.element_to_be_clickable((By.CLASS, xpath)))
            element.click();
        except:
            pass
        try:
            element = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS, 'brid-overlay-play-button brid-button')))
            element.click();
        except:
            pass
        try:
            element = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, 'onesignal-slidedown-cancel-button')))
            element.click();
        except:
            pass