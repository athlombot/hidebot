import pip
import subprocess
import subprocess
import sys

def install(package):
   subprocess.check_call([sys.executable, "-m", "pip", "install", package])    

errors = []

try:
    install('webdriver-manager')
    install('selenium')
    install('random')
    install('time')
except Exception as error:
    errors.append(error)

if len(errors):
   print(errors)
else:
   print("\n\nTodos los paquetes han sido instalados!")