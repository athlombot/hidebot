from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver import Chrome
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import time

PATH = "./webdriver/chromedriver"
options = webdriver.ChromeOptions()
options.add_argument('headless')
driver = webdriver.Chrome(PATH, options=options)

driver.get("https://petclips.tv/login.php")

print("Pagina Abierta: " , driver.title)
time.sleep(2)


with open('./Credenciales/hideout.txt', 'r') as f:
    for line in f:
        line_words = line.split()

time.sleep(2)

inputElement = driver.find_element_by_id("username")
inputElement.send_keys( line_words[0] )
print("Ingresando con el Usuario: ", line_words[0] )

time.sleep(1)

inputElement = driver.find_element_by_id("password")
inputElement.send_keys( line_words[1] )
print("Contraseña: ", line_words[1] )

time.sleep(1)

element = WebDriverWait(driver, 10).until(
EC.element_to_be_clickable((By.XPATH, '//*[@id="login"]/div[4]/button')))
element.click();
print("Entrando")

time.sleep(5)

driver.get("https://petclips.tv/rewards.php")

puntos = WebDriverWait(driver, 20).until(EC.visibility_of_all_elements_located((By.XPATH, "/html/body/div[8]/div[2]/div/div/div[1]/div[1]/div[1]/p/span[2]")))

for value in puntos:
        print("Tus Puntos es: " + value.text)



